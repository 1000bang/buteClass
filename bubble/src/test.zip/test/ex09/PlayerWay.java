package test.ex09;

public enum PlayerWay {
LEFT, RIGHT, UP
}
