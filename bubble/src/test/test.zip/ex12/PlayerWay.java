package test.ex12;

public enum PlayerWay {
LEFT, RIGHT, UP
}
