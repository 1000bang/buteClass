package test.ex12;

public enum EnemyWay {

	LEFT, RIGHT
}
