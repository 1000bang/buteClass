package test.ex11;

public enum PlayerWay {
LEFT, RIGHT, UP
}
